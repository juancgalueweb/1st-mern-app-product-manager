const Product = require("../models/pm.model");

// Method to create a product
module.exports.createProduct = async (req, res) => {
  try {
    const newProduct = await Product.create(req.body);
    return res.json({ storedProduct: newProduct });
  } catch (err) {
    res.json({ error: err });
  }
};
