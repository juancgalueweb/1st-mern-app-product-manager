import { ProductsNew } from "./components/ProductsNew";

function App() {
  return <ProductsNew />;
}

export default App;
